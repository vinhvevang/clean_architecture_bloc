import 'package:bloc_nearly_complete/features/product/domain/entities/product.dart';
import 'package:bloc_nearly_complete/features/product/domain/repository/product_repository.dart';

class FilterProduct {
  final ProductRepository repository;

  FilterProduct(this.repository);

  List<Product> call({int? minPrice, int? maxPrice}) {
    return repository.getProducts().where((p) {
      final matchesMin = minPrice == null || p.price >= minPrice;
      final matchesMax = maxPrice == null || p.price <= maxPrice;
      return matchesMin && matchesMax;
    }).toList();
  }
}
