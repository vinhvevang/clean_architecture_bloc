import 'package:bloc/bloc.dart';
import 'package:bloc_nearly_complete/features/product/domain/usecases/add_product.dart';
import 'package:bloc_nearly_complete/features/product/domain/usecases/edit_product.dart';
import 'package:bloc_nearly_complete/features/product/domain/usecases/find_product.dart';
import 'package:bloc_nearly_complete/features/product/domain/usecases/get_products.dart';
import 'package:bloc_nearly_complete/features/product/domain/usecases/remove_product.dart';
import 'package:bloc_nearly_complete/features/product/presentation/bloc/home_event.dart';
import 'package:bloc_nearly_complete/features/product/presentation/bloc/home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final AddProduct addProduct;
  final RemoveProduct removeProduct;
  final EditProduct editProduct;
  final FindProduct findProduct;
  final GetProducts getProducts;

  HomeBloc(
    this.addProduct,
    this.removeProduct,
    this.editProduct,
    this.findProduct,
    this.getProducts,
  ) : super(HomeState([], [])) {
    on<AddProductEvent>(_addProduct);
    on<RemoveProductEvent>(_removeProduct);
    on<EditProductEvent>(_editProduct);
    on<FindProductEvent>(_findProduct);
  }

  void _addProduct(event, emit) {
    addProduct(event.product);

    final all = getProducts();

    emit(HomeState(all, all));
  }

  void _removeProduct(event, emit) {
    removeProduct(event.id);

    final all = getProducts();

    emit(HomeState(all, all));
  }

  void _editProduct(event, emit) {
    editProduct(event.product, event.id);

    final all = getProducts();

    emit(HomeState(all, all));
  }

  void _findProduct(event, emit) {
    final filtered = findProduct(event.keyword);

    emit(HomeState(state.products, filtered));
  }
}