import 'package:bloc_nearly_complete/features/product/domain/entities/product.dart';

abstract class HomeEvent {}
class AddProductEvent extends HomeEvent{
  Product product;
  AddProductEvent(this.product);
}
class EditProductEvent extends HomeEvent{
  Product product;
  int id;
  EditProductEvent(this.product,this.id);
}
class RemoveProductEvent extends HomeEvent{
  int id;
  RemoveProductEvent(this.id);
}
class FindProductEvent extends HomeEvent{
  String name;
  FindProductEvent(this.name);
}
class FilterProductEvent extends HomeEvent{}