import 'package:bloc_nearly_complete/features/product/data/repositories/product_repository_impl.dart';
import 'package:bloc_nearly_complete/features/product/domain/entities/product.dart';
import 'package:bloc_nearly_complete/features/product/presentation/bloc/home_bloc.dart';
import 'package:bloc_nearly_complete/features/product/presentation/bloc/home_event.dart';
import 'package:bloc_nearly_complete/features/product/presentation/bloc/home_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  TextEditingController name = TextEditingController();
  TextEditingController price = TextEditingController();
  TextEditingController quan = TextEditingController();
  TextEditingController editName = TextEditingController();
  TextEditingController editPrice = TextEditingController();
  TextEditingController editQuan = TextEditingController();
  TextEditingController findName = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        BlocBuilder<HomeBloc, HomeState>(
          builder: (context, state) {
            return SafeArea(
              child: Container(
                height: 50,
                child: Scaffold(
                  body: TextFormField(
                    controller: findName,
                    onChanged: (value) {
                      context.read<HomeBloc>().add(FindProductEvent(value));
                    },
                    decoration: InputDecoration(
                      label: Text("Nhap ten sp ..."),
                      floatingLabelBehavior: FloatingLabelBehavior.never,
                    ),
                  ),
                ),
              ),
            );
          },
        ),

        Expanded(
          child: Scaffold(
            body: BlocBuilder<HomeBloc, HomeState>(
              builder: (_, state) {
                return GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    childAspectRatio: 0.8,
                    crossAxisSpacing: 3,
                    crossAxisCount: 2,
                  ),

                  itemCount: state.products.length,
                  itemBuilder: (context, i) {
                    return Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                      ),
                      child: Column(
                        children: [
                          ListTile(
                            title: Text(state.filteredProducts[i].name),
                            subtitle: Text("${state.filteredProducts[i].price}"),
                            trailing: Text("${state.filteredProducts[i].quan}"),
                          ),
                          IconButton(
                            onPressed:
                                () => context.read<HomeBloc>().add(
                                  RemoveProductEvent(i),
                                ),
                            icon: Icon(Icons.delete),
                          ),
                          IconButton(
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (context) {
                                  return AlertDialog(
                                    title: Text("Sua san pham"),
                                    actions: [
                                      TextFormField(
                                        controller: editName,
                                        decoration: InputDecoration(
                                          label: Text("Ten san pham"),
                                        ),
                                      ),
                                      TextFormField(
                                        controller: editPrice,
                                        decoration: InputDecoration(
                                          label: Text("gia"),
                                        ),
                                      ),
                                      TextFormField(
                                        controller: editQuan,
                                        decoration: InputDecoration(
                                          label: Text("so luong"),
                                        ),
                                      ),
                                      TextButton(
                                        onPressed: () {
                                          Product res = Product(
                                            editName.text,
                                            int.tryParse(editPrice.text) ?? 0,
                                            int.tryParse(editQuan.text) ?? 0,
                                          );
                                          context.read<HomeBloc>().add(
                                            EditProductEvent(res, i),
                                          );
                                          Navigator.pop(context);
                                        },
                                        child: Text("sua"),
                                      ),
                                    ],
                                  );
                                },
                              );
                            },
                            icon: Icon(Icons.edit),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
            floatingActionButton: FloatingActionButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text("nhap thong tin san pham"),
                      actions: [
                        TextFormField(
                          controller: name,
                          decoration: InputDecoration(
                            label: Text("Ten san pham"),
                          ),
                        ),
                        TextFormField(
                          controller: price,
                          decoration: InputDecoration(label: Text("gia")),
                        ),
                        TextFormField(
                          controller: quan,
                          decoration: InputDecoration(label: Text("so luong")),
                        ),
                        TextButton(
                          onPressed: () {
                            Product res = Product(
                              name.text,
                              int.tryParse(price.text) ?? 0,
                              int.tryParse(quan.text) ?? 0,
                            );
                            context.read<HomeBloc>().add(AddProductEvent(res));

                            // ProductRepositoryImpl().addProduct(res);
                          },
                          child: Text("them"),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Icon(Icons.add),
            ),
          ),
        ),
      ],
    );
  }
}
